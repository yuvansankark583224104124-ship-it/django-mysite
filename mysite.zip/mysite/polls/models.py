from django.db import models

class Student(models.Model):
    username = models.CharField(max_length=100)  # fixed 'max_Length' → 'max_length'
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)

    def __str__(self):  # fixed '_str_' → '__str__'
        return self.username

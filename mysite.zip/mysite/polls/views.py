from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Student

# Home page view
def home(request):
    return render(request, 'home.html')


# Register view
def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        # Check if email already exists
        if Student.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
            return redirect('register')
        
        # Save new student
        student = Student(username=username, email=email, password=password)
        student.save()  # Important: save to database
        messages.success(request, "Registration successful! Please login.")
        return redirect('login')
    
    return render(request, 'register.html')


# Login view
def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        try:
            student = Student.objects.get(email=email)
            
            if student.password == password:  # Correct password check
                # Set session
                request.session['student_id'] = student.id
                request.session['username'] = student.username
                messages.success(request, f"Welcome, {student.username}!")
                return redirect('dashboard')
            else:
                messages.error(request, "Invalid password")
        
        except Student.DoesNotExist:
            messages.error(request, "Email not registered")
    
    return render(request, 'login.html')


# Dashboard view
def dashboard(request):
    student_id = request.session.get('student_id')
    
    if not student_id:
        messages.error(request, "You must be logged in to view the dashboard")
        return redirect('login')
    
    student = Student.objects.get(id=student_id)
    context = {'student': student}
    return render(request, 'dashboard.html', context)
